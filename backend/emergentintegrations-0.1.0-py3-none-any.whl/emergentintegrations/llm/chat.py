"""
LLM integration using LiteLLM for flexible provider support.
"""
import pathlib
import litellm
import base64
import os
from litellm import ModelResponse
from typing import Callable, Dict, Any, List, Optional, Union
from emergentintegrations.llm.utils import get_app_identifier, get_integration_proxy_url

class FileContent:
    def __init__(self, content_type: str, file_content_base64: str) -> None:
        self.content_type = content_type
        self.file_content_base64 = file_content_base64
    
class ImageContent(FileContent):
    def __init__(self, image_base64: str) -> None:
        super().__init__("image", image_base64)

    @staticmethod
    def get_mime_type(file_content_base64) -> str:
        if file_content_base64.startswith('iVBORw0KGgo'):
            return 'image/png'
        elif file_content_base64.startswith('/9j/'):
            return 'image/jpeg'
        elif file_content_base64.startswith('R0lGOD'):
            return 'image/gif'
        elif file_content_base64.startswith('UklGR'):
            return 'image/webp'
        return 'image/png'  # Default to PNG for backwards compatibility
        
class FileContentWithMimeType(FileContent):
    def __init__(self, mime_type: str, file_path: str) -> None:
        file_bytes = pathlib.Path(file_path).read_bytes()
        file_content_base64 = base64.b64encode(file_bytes).decode('utf-8')
        super().__init__(mime_type, file_content_base64)

class UserMessage:
    def __init__(self, text: str = None, file_contents: list[FileContent] = None) -> None:
        self.text = text
        self.file_contents = file_contents or []  # Initialize as empty list if None

class LlmChat:
    """
    LLM integration using LiteLLM for generating chat completions.
    This class provides compatibility with OpenAI's API while supporting
    multiple LLM providers through LiteLLM.
    """

    def __init__(self, api_key: str, session_id: str, system_message: str, initial_messages: List[Dict[str, Any]] = None, custom_headers: Dict[str, str] = None):
        self.api_key = api_key    
        self.model = "gpt-4o" 
        self.messages = initial_messages or [{"role": "system", "content": system_message}]
        self.session_id = session_id
        self.provider = "openai"
        self.extra_params = {}
        self.custom_headers = custom_headers or {}

        app_url = get_app_identifier()
        if app_url:
            self.custom_headers['X-App-ID'] = app_url
        
    def with_model(self, provider: str, model: str) -> "LlmChat":
        self.provider = provider
        self.model = model
        return self
    
    def with_params(self, **params) -> "LlmChat":
        self.extra_params.update(params)
        return self
    
    async def _add_assistant_message(self, messages: List[Dict[str, Any]], message: str):
        messages.append({"role": "assistant", "content": message})
        await self._save_messages(messages)
    
    async def _add_user_message(self, messages, message: UserMessage):
        # Check if file contents are being used with non-Gemini provider
        if message.file_contents and any(isinstance(content, FileContentWithMimeType) for content in message.file_contents):
            if self.provider != "gemini":
                raise ChatError("File attachments are only supported with Gemini provider")
        
        if message.text:
            messages.append({"role": "user", "content": [{"type": "text", "text": message.text}]})
        for content in message.file_contents:
            if content.content_type == "image":
                mime_type = ImageContent.get_mime_type(content.file_content_base64)
                messages.append({"role": "user", "content": [{"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{content.file_content_base64}"}}]})
            else:
                messages.append({"role": "user", "content": [{"type": "file", "file": { "file_data": "data:{};base64,{}".format(content.content_type, content.file_content_base64) }}]})
        await self._save_messages(messages)
        
    async def get_messages(self) -> List[Dict[str, Any]]:
        return self.messages
    
    async def _save_messages(self, messages):
        self.messages = messages

    async def _execute_completion(self, messages: List[Dict[str, Any]]) -> ModelResponse:
        """Execute the completion request and return the raw response."""
        params = {
            "model": f"{self.provider}/{self.model}",
            "messages": messages,
            "api_key": self.api_key,  # Always include the API key
        }   

        if self._is_emergent_key(self.api_key):
            proxy_url = get_integration_proxy_url()
            params["api_base"] = proxy_url + "/llm"
            params["custom_llm_provider"]= "openai"
            if self.provider == "gemini":
                params["model"] = f"gemini/{self.model}"
            else:
                params["model"] = self.model
            
            # Add custom headers when using Emergent proxy
            if self.custom_headers:
                params["extra_headers"] = self.custom_headers

        # Merge extra params
        params.update(self.extra_params)

        return litellm.completion(**params)

    async def send_message(self, user_message: UserMessage) -> str:
        messages = await self.get_messages()
        await self._add_user_message(messages, user_message)
        try:
            response = await self._execute_completion(messages)
            response_text = await self._extract_response_text(response)
            await self._add_assistant_message(messages, response_text)  # Pass both messages and response_text
            return response_text
        except Exception as e:
            raise ChatError(f"Failed to generate chat completion: {str(e)}")
        

    async def _extract_response_text(self, response: ModelResponse) -> str:
        """
        Extract the text or content from a chat completion response.
        Handles various response formats including text and images.

        Args:
            response (Dict[str, Any]): The response from a chat completion request.

        Returns:
            str: The extracted content, which could be text or a structured representation
                 of images/multimodal content.
        """
        try:
            if len(response.choices) > 0 and response.choices[0].message:
                return response.choices[0].message.content
            raise ChatError(f"Failed to extract response text")
        except Exception as e:
            raise ChatError(f"Failed to extract response text: {str(e)}")

    def _is_emergent_key(self, api_key):
        return api_key.startswith("sk-emergent-")
    
    async def send_message_multimodal_response(self, user_message: UserMessage) -> tuple[str, List[Dict[str, str]]]:
        """
        Send a message and extract both text and images from the response.
        
        Returns:
            Tuple of (text, images) where images is a list of dicts with 'mime_type' and 'data' keys.
        """
        messages = await self.get_messages()
        await self._add_user_message(messages, user_message)
        try:
            response = await self._execute_completion(messages)
            
            # Extract multimodal content
            text = None
            images = []

            if len(response.choices) > 0 and response.choices[0].message:
                message = response.choices[0].message

                # Extract images from separate field (Gemini's LiteLLM format)
                if hasattr(message, 'images') and message.images:
                    for img_data in message.images:
                        if 'image_url' in img_data and 'url' in img_data['image_url']:
                            url = img_data['image_url']['url']
                            # Parse data URL: data:image/png;base64,<base64data>
                            if 'data:' in url and ';base64,' in url:
                                parts = url.split(';base64,', 1)
                                mime_type = parts[0].replace('data:', '')
                                base64_data = parts[1]
                                images.append({"mime_type": mime_type, "data": base64_data})

                # Extract text from content if present
                if message.content:
                    text = message.content
            
            # Save assistant message if text was returned
            if text:
                await self._add_assistant_message(messages, text)
            
            return text, images
            
        except Exception as e:
            raise ChatError(f"Failed to generate multimodal completion: {str(e)}")

class ChatError(Exception):
    """Exception raised for errors in the LLM chat integration."""
    pass
